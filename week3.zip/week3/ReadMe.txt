--------------------------------------------------------------------
Author Name : Tejaswini Gaddam

Final Project
--------------------------------------------------------------------

homepage.html is the home page which contains buttons on clikcing directs to approprite pages.

Week-3:
*******
Files Included: 
1.homepage.html
2.perspective.html
3.isometric.html
4.oblique.html
5.multiview.html

--For this week, I have implemented the different views and the projections of the 3d object created.

--The different types of projections are the Multiview, Oblique, Axonometric and Perspective projections.

-- Multivew Projections showcased the front, top, left side, right side, back and bottom side views of the object.

--Perspective projections showcases the 1 point, 2point and 3 point projections.

-- Axonometric has the Isometric, Dimetric and Trimetric views of the object. 

Week-2:
********
Files Included: 
1.homepage.html
2.housetrans.html
3.piletrans.html
4.slidetrans.html

--Last week I developed the 2d views of the object and developed a 3d model for the objects.

-- This week for the created object i have implemented the 3d transformations on them.

-- The transformations are translation, rotation, scaling and shearing.

-- Giving the particular value in the textboxes provided it changes the positions or the size of the object.

Week-1:
*********
-- In the 2d views, On clicking "House" it goes to house.html page which shows the front side and top view of the house, there is a link on the page for viewing 3d model of the house.

-- On clicking "slidingbox" it goes to slide.html page which shows the front side and top view of the image, there is a link on the page for viewing 3d model of the sliding box.

--On clicking "Pile of boxes" it goes to pile.html page which shows the front side and top view of the boxes, there is a link on the page for viewing 3d model of the boxes.

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
3.https://study.com/academy/lesson/what-is-an-isometric-drawing-definition-examples.html  