--------------------------------------------------------------------
Author Name : Tejaswini Gaddam

Final Project
--------------------------------------------------------------------

Week 4: 
**********
1.camera.html
2.light.html
3.CanvasReader.js
4.Detector.js
5.Projector.js
6.three.js
7.ObjectControls.js

- For this week I have used three.js and impletmented the change in the position of the light and camera with respective to the object.
- For the change in the light, I have also created the option to change the intensity of the light.
- I have also implemented the orthographic view of the camera views of the object.

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
3.https://study.com/academy/lesson/what-is-an-isometric-drawing-definition-examples.html  
4.https://github.com/mrdoob/three.js/