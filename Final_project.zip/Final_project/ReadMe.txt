--------------------------------------------------------------------
Author Name : Tejaswini Gaddam

Final Project
--------------------------------------------------------------------

Files Included: 
1.house.html
2.house3d.html
3.housetrans.html
4.pile.html
5.pile3d.html
6.piletrans.html
7.slide.html
8.slide3d.html
9.slidetrans.html
10.style.css

-- homepage.html is the home page which contains buttons on clikcing directs to approprite pages.

Week-2:

--Last week I developed the 2d views of the object and developed a 3d model for the objects.

-- This week for the created object i have implemented the 3d transformations on them.

-- The transformations are translation, rotation, scaling and shearing.

-- Giving the particular value in the textboxes provided it changes the positions or the size of the object.

Week-1:

-- In the 2d views, On clicking "House" it goes to house.html page which shows the front side and top view of the house, there is a link on the page for viewing 3d model of the house.

-- On clicking "slidingbox" it goes to slide.html page which shows the front side and top view of the image, there is a link on the page for viewing 3d model of the sliding box.

--On clicking "Pile of boxes" it goes to pile.html page which shows the front side and top view of the boxes, there is a link on the page for viewing 3d model of the boxes.

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
  