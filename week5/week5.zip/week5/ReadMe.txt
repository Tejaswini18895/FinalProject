--------------------------------------------------------------------
Author Name : Tejaswini Gaddam

Final Project
--------------------------------------------------------------------

Week 5: 
**********
1.3dobjectstexture.html
2.Texture_Change.html
3.video_texture.html

- For this week I tried implementing different textures on the objects.
- I created different 3d objects like cylinder, cone, cube, octahedron, sphere, Torus and Torus knot. I have implemented the compressed textures, some of them are the opaque textures, some are transparent with sharp alpha transitions and some transparent textures with full alpha transitions. 

- Apart from them I have created a 3d sphere, where we can change the textures to red in any desired pattern. I have implemented this using the help of the Three.js.

--I have also implemented a video texture on the object. Viedo will be playing on the face and it has controls to stop, pause, rewind and play.

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
3.https://github.com/mrdoob/three.js/